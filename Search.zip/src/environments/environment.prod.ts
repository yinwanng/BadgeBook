export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCwg2pDbT4-DzfqUM2o0QdLhmYSqv4VhiA",
    authDomain: "badgebook-91d29.firebaseapp.com",
    databaseURL: "https://badgebook-91d29.firebaseio.com",
    projectId: "badgebook-91d29",
    storageBucket: "badgebook-91d29.appspot.com",
    messagingSenderId: "233373261567"
  }
};
